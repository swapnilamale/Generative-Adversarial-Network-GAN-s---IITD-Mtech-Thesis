sobolseq51.dll to be placed here.
This file may be freely downloaded from BRODA at: http://www.broda.co.uk/