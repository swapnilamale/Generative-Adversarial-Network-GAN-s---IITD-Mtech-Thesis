
function s=get_name(a)

s=get_name(a.algorithm);    
s=[s ' k=' num2str(a.k)];
eval_name

