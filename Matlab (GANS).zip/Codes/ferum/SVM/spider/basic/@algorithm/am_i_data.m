
function b=am_i_data(dat)
%
%            bool = am_i_dat(data)
%
% Returns true if this object is data, else it false is returned
  
  b=dat.is_data;    