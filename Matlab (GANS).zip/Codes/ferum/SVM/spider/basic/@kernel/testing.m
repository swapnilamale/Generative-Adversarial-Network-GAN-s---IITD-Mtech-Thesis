
function d = testing(a,d)
  
  d=set_x(d,feval('calc',a,d,a.dat)); 
