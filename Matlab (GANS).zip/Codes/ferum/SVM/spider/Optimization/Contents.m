% Optimization routines for spider learning
