% System reliability analysis of corroding pipelines
% Code written by Souvik Chakraborty
% Department of Applied Mechanics, IIT Delhi
% --------------------------------------------------------

clc, clear;

crack_growth            = 2;                   % 1 = linear, 2 = gamma process
eg_number               = 1;
opt                     = 1;
ndefect                 = 1;

if crack_growth         == 1
    cd('./Linear')
    Pf                  = pipe_reliability_main(eg_number,opt,ndefect);
elseif crack_growth     == 2
    cd('./Gamma')
    Pf                  = pipe_reliability_main(eg_number,opt,ndefect);
end