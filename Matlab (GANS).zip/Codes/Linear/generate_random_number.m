function [z,x,dist_param]  = generate_random_number(mu,sd,type,corr_mat,nsimu)
% Random number generation
% Code written by Souvik Chakraborty
% Department of Applied Mechanics, IIT Delhi
% --------------------------------------------------------
% INPUTS:
% mu = mean
% sd = stadard deviation
% type = distribution type (1 = normal, 2 = lognormal, 3 = uniform, 4= gumbell, 5 = weibull)
% nsimu = number of samples to generate
%
% OUTPUTS:
% z = equivalent standard normally distributed random numbers
% x = random numbers from the distribution
% ---------------------------------------------------------

nvar            = length(mu);
z_uni           = rand(nsimu,nvar);
zuncorr         = norminv(z_uni);

L               = chol(corr_mat);

zcorr           = zuncorr*L;
zcorr_uni       = normcdf(zcorr);

x = zeros(nsimu,nvar);
dist_param = zeros(nvar,2);
for ivar = 1 : nvar
    if type(ivar)     == 1
        x(:,ivar) = mu(ivar)+sd(ivar)*zcorr(:,ivar);
        dist_param(ivar,1) = mu(ivar);
        dist_param(ivar,2) = sd(ivar);
    elseif type(ivar) == 2
        muN = log(mu(ivar)^2/(sqrt(sd(ivar)^2 + mu(ivar)^2)));
        sdN = sqrt(log((sd(ivar)/mu(ivar))^2 + 1));
        x(:,ivar)   = exp(muN + sdN*zcorr(:,ivar));
        dist_param(ivar,1) = muN;
        dist_param(ivar,2) = sdN;
    elseif type(ivar) == 3
        lb  = mu(ivar) - sqrt(3)*sd(ivar);
        ub  = mu(ivar) + sqrt(3)*sd(ivar);
        x(:,ivar)   = ub + (ub - lb)*zcorr_uni(:,ivar);
        dist_param(ivar,1) = lb;
        dist_param(ivar,2) = ub;
    elseif type(ivar) == 4
        gamma_gumb       = 0.5772;
        beta_gumb        = sd(ivar)*sqrt(6)/pi;
        mu_gumb          = mu(ivar) - gamma_gumb*beta_gumb;
        x(:,ivar)        = mu_gumb - beta_gumb.*log(-log(zcorr_uni(:,ivar)));
        dist_param(ivar,1) = mu_gumb;
        dist_param(ivar,2) = beta_gumb;
    elseif type(ivar) == 5
        param0          = [1,1];
        param           = fsolve(@(param)weibull_param(param,mu(ivar),sd(ivar)), param0);
        lambda          = param(1);
        k               = param(2);
        x(:,ivar)       = lambda*nthroot(-log(-(zcorr_uni(:,ivar) - 1)),k);
        dist_param(ivar,:) = param;
    else
        error('The specified type is not yet added')
    end
end
z = zuncorr;
end