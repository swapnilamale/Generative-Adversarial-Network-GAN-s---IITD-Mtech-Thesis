function Pf = pipe_reliability_main(eg_number,opt,ndefect)
% System reliability analysis of corroding pipelines
% Code written by Souvik Chakraborty
% Department of Applied Mechanics, IIT Delhi
% --------------------------------------------------------
% INPUTS:
% eg_number = example number
% opt       = which reliability analysis tool you want to use
%               [opt = 1 (MCS), 2 (SS), 3 (DS), 4(IS), 5 (FORM), 6 (SORM)]
% ndefect   = number of defects
%
% OUTPUT:
% Pf        = Probability of failure: 
%                     Pf(1) = PF due to leak
%                     Pf(2) = PF due to burst
% ---------------------------------------------------------
if nargin < 3
    ndefect = 1;
    if nargin < 2
        opt = 1;            %opt = 1 (MCS), 2 (SS), 3 (DS), 4(IS), 5 (FORM), 6 (SORM)
        if nargin < 1
            eg_number = 1;
        end
    end
end

if eg_number == 1
    F               = 0.72;
    Dn              = 914;              % in mm
    wtn             = 13.14;            % in mm
    SMTS            = 565;              % in MPa
    SMYS            = 483;              % in MPa
    Pn              = 10;               % in MPa
    mu_gd1          = 0.4;              % in mm/year
    sd_gd1          = mu_gd1*50/100;
elseif eg_number == 2
    F               = 0.6;
    Dn              = 610;              % in mm
    wtn             = 8.62;             % in mm
    SMTS            = 517;              % in MPa
    SMYS            = 413;              % in MPa
    Pn              = 7;                % in MPa
    mu_gd1          = 0.3;              % in mm/year
    sd_gd1          = mu_gd1*50/100;
elseif eg_number == 3
    F               = 0.5;
    Dn              = 508;              % in mm
    wtn             = 7.38;             % in mm
    SMTS            = 517;              % in MPa
    SMYS            = 413;              % in MPa
    Pn              = 6;                % in MPa
    mu_gd1          = 0.2;              % in mm/year
    sd_gd1          = mu_gd1*50/100;
elseif eg_number == 4
    F               = 0.4;
    Dn              = 406;              % in mm
    wtn             = 7.07;             % in mm
    SMTS            = 455;              % in MPa
    SMYS            = 359;              % in MPa
    Pn              = 5;                % in MPa
    mu_gd1          = 0.2;              % in mm/year
    sd_gd1          = mu_gd1*50/100;
else
    error('Wrong input')
end

% System parameters

D                   = 1.0*Dn;

mu_wt               = 1.0*wtn;
sd_wt               = mu_wt*1.5/100;
type_wt             = 1;                        % Normal distribution.

mu_sigmau           = 1.09*SMTS;
sd_sigmau           = mu_sigmau*3/100;
type_sigmau         = 2;                        % Lognormal distribution.

mu_P                = 1.0*Pn;
sd_P                = mu_P*3/100;
type_P              = 4;                        % Gumbell distribution.

mu_d01              = 0.2*wtn;
sd_d01              = mu_d01*20/100;
type_d01            = 1;                        % Normal distribution.

mu_d02              = 0.3*wtn;
sd_d02              = mu_d02*20/100;
% type_d01            = 1;                        % Normal distribution.


mu_l01              = 50;                       % in mm
sd_l01              = mu_l01*20/100;
type_l01            = 1;                        % Normal distribution

mu_gl1              = 5.0;                      % in mm/year
sd_gl1              = mu_gl1*50/100;
type_gl1            = 2;                        % lognormal distribution

mu_xi               = 1.0;
sd_xi               = mu_xi*10/100;
type_xi             = 2;                        % Lognormal distribution;

tyep_gd1            = 5;                        % Weibull distribution

if ndefect <=5
    mu_comb             = [mu_wt, mu_sigmau, mu_P, mu_d01*ones(1,ndefect), mu_l01*ones(1,ndefect),...
                            mu_gd1*ones(1,ndefect), mu_gl1*ones(1,ndefect), mu_xi];
    sd_comb             = [sd_wt, sd_sigmau, sd_P, sd_d01*ones(1,ndefect), sd_l01*ones(1,ndefect),...
                            sd_gd1*ones(1,ndefect), sd_gl1*ones(1,ndefect), sd_xi];
    type_comb           = [type_wt, type_sigmau, type_P, type_d01*ones(1,ndefect),...
                            type_l01*ones(1,ndefect), tyep_gd1*ones(1,ndefect), type_gl1*ones(1,ndefect), type_xi];
else
    mu_comb             = [mu_wt, mu_sigmau, mu_P, mu_d01*ones(1,5), mu_d02*ones(1,ndefect-5), mu_l01*ones(1,ndefect),...
                            mu_gd1*ones(1,ndefect), mu_gl1*ones(1,ndefect), mu_xi];
    sd_comb             = [sd_wt, sd_sigmau, sd_P, sd_d01*ones(1,5), sd_d02*ones(1,ndefect-5), sd_l01*ones(1,ndefect),...
                            sd_gd1*ones(1,ndefect), sd_gl1*ones(1,ndefect), sd_xi];
    type_comb           = [type_wt, type_sigmau, type_P, type_d01*ones(1,ndefect),...
                            type_l01*ones(1,ndefect), tyep_gd1*ones(1,ndefect), type_gl1*ones(1,ndefect), type_xi];
end

nvar                = length(type_comb);

corr_mat            = eye(nvar);
for ivar = 1 : ndefect
    corr_mat(5+ivar,5+ndefect+ivar)       = 0.5;
    corr_mat(5+ndefect+ivar,5+ivar)       = 0.5;
end

param.mu            = mu_comb;
param.sd            = sd_comb;
param.type          = type_comb;
param.corrmat       = corr_mat;

if opt == 1
    nsimu               = 1e7;
    paras= [];
    nrun = 1;
elseif opt == 2
    nsimu           = 300;
    paras.NumSam    = nsimu;
    paras.CondPro   = 0.15;
    paras.MaxTry    = 10;
    nrun            = 10;
elseif opt == 4 || opt == 5 || opt == 6
    nsimu           = 1e3;
    paras           = [];
    nrun            = 1;
elseif opt == 3
    nsimu           = 1e4;
    paras           = [];
    nrun            = 1;
end

[zrand, xrand, dist_param]      = generate_random_number(mu_comb,...
                                  sd_comb,type_comb,corr_mat,...
                                  nsimu);
                              
param.dist_param                = dist_param; 

tau_start   = 1;
tau_end     = 10;
Pf = zeros(tau_end,2); 
if opt == 1 || opt == 2
    
    
    for jtau    = tau_start:tau_end
        Pfint = 0;
        for irun = 1 : nrun
            Pfint      = Pfint + compute_Pf(D,xrand,zrand,jtau,opt,ndefect,param,paras,nsimu);
        end
        Pf(jtau,:) = Pfint/nrun;
        if jtau > 1 % && opt == 1
            Pf(jtau,:) = Pf(jtau,:)+Pf(jtau-1,:);
        end
    end
else
    Pf1 = compute_Pf(D,xrand,zrand,tau_end,opt,ndefect,param,paras,nsimu);
    for jtau = tau_start+1:tau_end
        Pf(jtau,:) = sum(Pf1(1:jtau,:),1);
    end
end

semilogy(1:10,Pf(:,1), 1:10, Pf(:,2))
% ylim([1e-12,1e0])
xlim([0,11])
