function g = limit_state(X1,X2,X3,X4,X5,X6,X7,X8,X9,X10,X11,X12,X13,X14,X15,X16,X17,X18,X19,X20,X21,X22,X23,X24,X25,X26,X27,X28,X29,X30,X31,X32,X33,X34,X35,X36,X37,X38,X39,X40,X41,X42,X43,X44)

global jtau ivar1 Dglob ndefect_glob param_glob

zrand   = [X1(:),X2(:),X3(:),X4(:),X5(:),X6(:),X7(:),X8(:),X9(:),X10(:),X11(:),X12(:),X13(:),X14(:),X15(:),X16(:),X17(:),X18(:),X19(:),X20(:),X21(:),X22(:),X23(:),X24(:),X25(:),X26(:),X27(:),X28(:),X29(:),X30(:),X31(:),X32(:),X33(:),X34(:),X35(:),X36(:),X37(:),X38(:),X39(:),X40(:),X41(:),X42(:),X43(:),X44(:)];

ndefect = ndefect_glob;
param   = param_glob;
D       = Dglob;
outvar  = ivar1;


type                            = param.type;
corrmat                         = param.corrmat;
dist_param                      = param.dist_param;

xrand                           = z2x(zrand,type,dist_param,corrmat);

wt                              = xrand(:,1);
sigmau                          = xrand(:,2);
P                               = xrand(:,3);
d01                             = xrand(:,4:4+ndefect-1);
l01                             = xrand(:,4+ndefect:4+ndefect+ndefect-1);
gd1                             = xrand(:,4+ndefect+ndefect:...
                                        4+ndefect+ndefect+ndefect-1);
gl1                             = xrand(:,4+ndefect+ndefect+ndefect:...
                                        4+ndefect+ndefect+ndefect+ndefect-1);
xi                              = xrand(:,end);

gll1                            = zeros(size(wt,1),ndefect);
gb1                             = gll1;
gl0               = gll1;
gb0               = gll1;

for idefect = 1 : ndefect
    d1                          = d01(:,idefect)+gd1(:,idefect)*jtau;
    l1                          = l01(:,idefect)+gl1(:,idefect)*jtau;
    
    gll1(:,idefect)             = 0.8*wt - d1;                                                      % Leak failure
    
    gb1(:,idefect)              = xi.*(2.*wt.*sigmau/D).*(1 - (d1./wt).*...
                                    (1 - exp((-0.157*l1./...
                                    (sqrt(D.*(wt - d1)/2)))))) - P;
    if jtau > 1
        d0               = d01(:,idefect)+gd1(:,idefect)*(jtau - 1);
        l0               = l01(:,idefect)+gl1(:,idefect)*(jtau - 1);
        
        gl0(:,idefect)   = 0.8*wt - d0;                                                      % Leak failure
        
        gb0(:,idefect)   = xi.*(2.*wt.*sigmau/D).*(1 - (d0./wt).*(1 - exp((-0.157*l0./...
                                (sqrt(D.*(wt - d0)/2)))))) - P;
    end
                                
end
if jtau == 1
    gl                          = min(gll1,[],2);
    gb                          = min(gb1,[],2);
else
    gl               = min((gll1.*gl0),[],2);
    gb               = (min((gb1.*gb0),[],2));
end

if outvar       == 1
    g = gl;
elseif outvar   == 2
    g = gb;
end