function x = z2x(z,type,dist_param,corrmat)
% System reliability analysis of corroding pipelines using MCS
% Code written by Souvik Chakraborty
% Department of Applied Mechanics, IIT Delhi
% -----------------------------------------------------
% INPUTS:
% z         = random numbers in standard normal space
% type      = distribution of the random variables
% dist_para = parameters of the random variables
%
% OUTPUT
% x         = random numbers in original space
% -----------------------------------------------------

nvar            = length(type);
L               = chol(corrmat);

zcorr           = z*L;
u               = normcdf(zcorr);

x = zeros(size(z));

for ivar = 1 : nvar
    if type(ivar)     == 1
        x(:,ivar) = dist_param(ivar,1)+dist_param(ivar,2)*zcorr(:,ivar);
    elseif type(ivar) == 2
        x(:,ivar)   = exp(dist_param(ivar,1) + dist_param(ivar,2)*zcorr(:,ivar));
    elseif type(ivar) == 3
        x(:,ivar)   = dist_param(ivar,2) + (dist_param(ivar,2) - dist_param(ivar,1))*u(:,ivar);
    elseif type(ivar) == 4
        x(:,ivar)        = dist_param(ivar,1) - dist_param(ivar,2).*log(-log(u(:,ivar)));
    elseif type(ivar) == 5
        x(:,ivar)       = dist_param(ivar,1)*nthroot(-log(-(u(:,ivar) - 1)),dist_param(ivar,2));
    else
        error('The specified type is not yet added')
    end
end