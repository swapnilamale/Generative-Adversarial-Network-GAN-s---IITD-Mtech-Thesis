function Pf = MCS(D,xrand,~,jtau,ndefect)
% System reliability analysis of corroding pipelines using MCS
% Code written by Souvik Chakraborty
% Department of Applied Mechanics, IIT Delhi
% -----------------------------------------------------
% INPUTS:
% D         = outer diameter
% xrand     = random numbers in problem space
% jtau      = current time-step
% ndefect   = number of defects
%
% OUTPUT:
% Pf            = probability of failure: Pf(1)=leak failure, Pf(2) = burst failure
% -------------------------------------------------------
[gl,gb] = limit_state(D,xrand,jtau,ndefect);

nfail1   = sum(gl==1);
nfail2   = sum(gb==1);

Pf(1)    = nfail1/size(xrand,1);
Pf(2)    = nfail2/size(xrand,1);
end