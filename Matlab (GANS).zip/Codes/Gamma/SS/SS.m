function pf = SS(Fun,D,xrand,zrand,jtau,ndefect,param,paras)
% System reliability analysis of corroding pipelines: SS 
% Code written by Souvik Chakraborty
% Department of Applied Mechanics, IIT Delhi
% -----------------------------------------------------
% INPUTS:
% Fun       = limit state function
% D         = outer diameter
% xrand     = random numbers in problem space
% zrand     = random numbers in standard normal space
% jtau      = current time-step
% ndefect   = number of defects
% param     = parameters for the problem
% paras     = SS parameters
% Outputs:
% Pf            = probability of failure: Pf(1)=leak failure, Pf(2) = burst failure
% -------------------------------------------------------
% Algorithm parameters
N = paras.NumSam;
p0 = paras.CondPro;
nt = round(N*p0);
ns = ceil(1/p0-1);
n  = size(xrand,2);
%% Step 1 (Monte Carlo simulation)
z = zrand; % Generate standard normal samples
% Calculate LSF
for i=1:N 
    [g(i),h(i)] = feval(Fun,D,z(i,:),jtau,ndefect,param);
end
% Sort samples and LSF values
[gSort,index1]=sort(g);
[hSort,index2]=sort(h);
Z1 = z(index1,:);
Z2 = z(index2,:);
% Record the calculated results
pfss1 = nt/N;
pfss2 = nt/N;
gRe = gSort;
hRe = hSort;
cdf = (N-[N:-1:1]+1)/N;
zRe1 = Z1;
zRe2 = Z2;
%% Step 2 (Markov Chain Monte Carlo)
% preparation for MCMC
sigma1 = std(Z1(1:nt,:),0,1);
sigma2 = std(Z2(1:nt,:),0,1);
stopFlag = 0;
iter = 1;
while (stopFlag == 0)
    w = Z1(1:nt,:); 
    g = gSort(1:nt);
    iter = iter+1;
    len = nt+1;
    for i=1:nt
        seed = w(i,:); 
        seed_g = g(i);
        for j = 1:ns % A Markov chain
            for k = 1:n % Component by component
                % Generate an candidate            
                u(k) = seed(k)+(2*rand()-1)*sigma1(k);
                % Calculate the acceptance probability
                pdf2 = exp(-0.5*seed(k).^2);
                pdf1 = exp(-0.5*u(k).^2);
                alpha = pdf1/pdf2;
                % Accept u(k) with a probability of alpha
                if  alpha > rand() 
                    w(len,k)= u(k);
                else 
                    w(len,k)= seed(k);
                end
            end 
            [gTemp,~] = feval(Fun,D,w(len,:),jtau,ndefect,param);
            % Accept or reject 
            if gTemp <= gSort(nt+1)
                g(len) = gTemp;
                seed = w(len,:); 
                seed_g = g(len);
            else
                g(len) = seed_g;
                w(len,:) = seed;              
            end
            len = len+1;
            % terminate the simulation of a Markov chain
            if len > N 
                break; 
            end
        end
        if len > N 
            break; 
        end
    end
    % Sort samples and LSF values
    [gSort,index]=sort(g);
    Z1 = w(index,:); 
    % Record the calculated results
    gRe = [gSort,gRe(nt+1:end)];
    cdf = [(N-[N:-1:1]+1)/N*(nt/N)^(iter-1),cdf(nt+1:end)];
    zRe1 = [Z1;zRe1(nt+1:end,:)];
    % Terminate simulation   
    if iter >= paras.MaxTry || gSort(nt+1) <= 0
        pfss1 = pfss1*(size(find(g<0),2)/N);
        stopFlag = 1;    
        break;
    else
        pfss1 = pfss1*(nt/N);
    end
end

pf(1) = pfss1;
stopFlag = 0;
iter = 1;
while (stopFlag == 0)
    w = Z2(1:nt,:); 
    h = hSort(1:nt);
    iter = iter+1;
    len = nt+1;
    for i=1:nt
        seed = w(i,:); 
        seed_h = h(i);
        for j = 1:ns % A Markov chain
            for k = 1:n % Component by component
                % Generate an candidate            
                u(k) = seed(k)+(2*rand()-1)*sigma2(k);
                % Calculate the acceptance probability
                pdf2 = exp(-0.5*seed(k).^2);
                pdf1 = exp(-0.5*u(k).^2);
                alpha = pdf1/pdf2;
                % Accept u(k) with a probability of alpha
                if  alpha > rand() 
                    w(len,k)= u(k);
                else 
                    w(len,k)= seed(k);
                end
            end 
            [~,hTemp] = feval(Fun,D,w(len,:),jtau,ndefect,param);
            % Accept or reject 
            if hTemp <= hSort(nt+1)
                h(len) = hTemp;
                seed = w(len,:); 
                seed_h = h(len);
            else
                h(len) = seed_h;
                w(len,:) = seed;              
            end
            len = len+1;
            % terminate the simulation of a Markov chain
            if len > N 
                break; 
            end
        end
        if len > N 
            break; 
        end
    end
    % Sort samples and LSF values
    [hSort,index]=sort(h);
    Z2 = w(index,:); 
    % Record the calculated results
    hRe = [hSort,hRe(nt+1:end)];
    cdf = [(N-[N:-1:1]+1)/N*(nt/N)^(iter-1),cdf(nt+1:end)];
    zRe2 = [Z2;zRe2(nt+1:end,:)];
    % Terminate simulation   
    if iter >= paras.MaxTry || hSort(nt+1) <= 0
        pfss2 = pfss2*(size(find(h<0),2)/N);
        stopFlag = 1;    
        break;
    else
        pfss2 = pfss2*(nt/N);
    end
end
pf(2) = pfss2;
end