function Pf = SSimulation(D,xrand,zrand,jtau,ndefect,param,paras)
% System reliability analysis of corroding pipelines using SS
% Code written by Souvik Chakraborty
% Department of Applied Mechanics, IIT Delhi
% -----------------------------------------------------
% INPUTS:
% D         = outer diameter
% xrand     = random numbers in problem space
% zrand     = random numbers in standard normal space
% jtau      = current time-step
% ndefect   = number of defects
% param     = parameters for the problem
% paras     = SS parameters
%
% OUTPUT:
% Pf            = probability of failure: Pf(1)=leak failure, Pf(2) = burst failure
% -------------------------------------------------------
cd('./SS')
if jtau < 3
    paras.CondPro   = 0.05;
end
Pf              = SS(@limit_state,D,xrand,zrand,jtau,ndefect,param,paras);
cd('../')
end