function x = z2x(z,type,dist_param)

nvar            = length(type);

zcorr           = z;
u               = normcdf(zcorr);

x = zeros(size(z));

for ivar = 1 : nvar
    if type(ivar)     == 1
        x(:,ivar) = dist_param(ivar,1)+dist_param(ivar,2)*zcorr(:,ivar);
    elseif type(ivar) == 2
        x(:,ivar)   = exp(dist_param(ivar,1) + dist_param(ivar,2)*zcorr(:,ivar));
    elseif type(ivar) == 3
        x(:,ivar)   = dist_param(ivar,2) + (dist_param(ivar,2) - dist_param(ivar,1))*u(:,ivar);
    elseif type(ivar) == 4
        x(:,ivar)        = dist_param(ivar,1) - dist_param(ivar,2).*log(-log(u(:,ivar)));
    elseif type(ivar) == 5
        x(:,ivar)       = dist_param(ivar,1)*nthroot(-log(-(u(:,ivar) - 1)),dist_param(ivar,2));
    elseif type(ivar) == 6
        x(:,ivar)       = gaminv(u(:,ivar),dist_param(ivar,1),1/dist_param(ivar,2));
    else
        error('The specified type is not yet added')
    end
end