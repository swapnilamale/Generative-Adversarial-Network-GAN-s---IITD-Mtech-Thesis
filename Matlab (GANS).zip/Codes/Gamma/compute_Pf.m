function Pf = compute_Pf(D,xrand,zrand,jtau,opt,ndefect,param,paras,nsimu)
% System reliability analysis of corroding pipelines
% Code written by Souvik Chakraborty
% Department of Applied Mechanics, IIT Delhi
% -----------------------------------------------------
% INPUTS:
% D             = outer diameters of pipeline
% xrand         = random number in original problem domain
% zrand         = random numbers in standard normal space
% jtau          = current time-step (if opt = 1 or 2)/total time-steps (elsewhere)
% opt           = choice of reliability analysis tool (1 = MCS, 2 = SS, 3 = DS, 4 = IS, 5 = FORM, 6 = SORM
% ndefect       = number of defects
% param         = parameters of the problem
% paras         = parameters of the solver
% nsimu         = number of simulations
%
% OUTPUT:
% Pf            = probability of failure: Pf(1)=leak failure, Pf(2) = burst failure
% -------------------------------------------------------
if opt == 1
    Pf = MCS(D,xrand,zrand,jtau,ndefect);
elseif opt == 2
    Pf = SSimulation(D,xrand,zrand,jtau,ndefect,param,paras);
elseif opt == 3 || opt == 4 || opt == 5 || opt == 6
    Pf = FORM_SORM_IS_DS(D,xrand,zrand,jtau,ndefect,param,nsimu,opt);
else
    error('Specify Opt between 1 - 6')
end

end