function [gl,gb] = limit_state(D,xrand,jtau,ndefect)
% System reliability analysis of corroding pipelines: LS for MCS
% Code written by Souvik Chakraborty
% Department of Applied Mechanics, IIT Delhi
% -----------------------------------------------------
% INPUTS:
% D         = outer diameter
% xrand     = random numbers in problem space
% jtau      = current time-step
% ndefect   = number of defects
% Outputs:
% gl        = limit-state due to leak
% gb        = limit-state due to burst
% ------------------------------------------------------

wt              = xrand(:,1);
sigmau          = xrand(:,2);
P               = xrand(:,3);
d01             = xrand(:,4:4+ndefect-1);
l01             = xrand(:,4+ndefect:4+ndefect+ndefect-1);
gd1             = xrand(:,4+ndefect+ndefect:4+ndefect+ndefect+10-1);
gl1             = xrand(:,4+ndefect+ndefect+10:4+ndefect+ndefect+10+ndefect-1);
xi              = xrand(:,end);

gll1              = zeros(size(wt,1),ndefect);
gb1               = gll1;
gl0               = gll1;
gb0               = gll1;
for idefect = 1 : ndefect
    d1             = d01(:,idefect)+gd1(:,jtau);
    l1             = l01(:,idefect)+gl1(:,idefect)*jtau;
    
    gll1(:,idefect)              = 0.8*wt - d1;                                                      % Leak failure
    
    gb1(:,idefect)              = xi.*(2.*wt.*sigmau/D).*(1 - (d1./wt).*(1 - exp((-0.157*l1./...
        (sqrt(D.*(wt - d1)/2)))))) - P;
    if jtau > 1
        d0               = d01(:,idefect)+gd1(:,jtau-1);
        l0               = l01(:,idefect)+gl1(:,idefect)*(jtau - 1);
        
        gl0(:,idefect)   = 0.8*wt - d0;                                                      % Leak failure
        
        gb0(:,idefect)   = xi.*(2.*wt.*sigmau/D).*(1 - (d0./wt).*(1 - exp((-0.157*l0./...
                                (sqrt(D.*(wt - d0)/2)))))) - P;
%         gl               = double((gl1<0) & (gl0>=0));
%         gb               = double((gb1<0) & (gb0>=0));
%     else
%         gl               = double(gl1<0);
%         gb               = double(gb1<0);
    end
end
if jtau == 1
    gl = double(min(gll1,[],2)<0);
    gb = double(min(gb1,[],2)<0);
else
    gl               = double((min(gll1,[],2)<0) & (min(gl0,[],2)>=0));
    gb               = double((min(gb1,[],2)<0) & (min(gb0,[],2)>=0));
end

% gl = zeros(size(xrand,1),1);
% gb = zeros(size(xrand,1),1);
% for icrack = 1:ncrack
%   gl = gl<0 |   
% Burst failure


end