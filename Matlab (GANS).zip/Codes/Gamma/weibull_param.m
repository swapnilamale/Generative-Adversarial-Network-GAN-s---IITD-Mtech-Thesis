function F = weibull_param(param,mu,sd)
% Objective function for weibull parameter generation
% Code written by Souvik Chakraborty
% Department of Applied Mechanics, IIT Delhi
% --------------------------------------------------------
% INPUTS:
% params = parameters to be computed
% sd = stadard deviation
% mu = mean
%
% OUTPUTS:
% F = objective function
% ---------------------------------------------------------

lambda  = param(1);
k       = param(2);

F(1)    = lambda*gamma(1 + 1/k) - mu;

F(2)    = lambda^2*(gamma(1 + 2/k) - (gamma(1 + 1/k))^2) - sd^2;
end