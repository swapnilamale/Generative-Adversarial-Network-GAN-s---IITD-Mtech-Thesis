function Pf = FORM_SORM_IS_DS(D,~,~,ntau,ndefect,param,nsimu,opt)
% System reliability analysis of corroding pipelines using FORM/SORM/IS/DS
% Code written by Souvik Chakraborty
% Department of Applied Mechanics, IIT Delhi
% -----------------------------------------------------
% INPUTS:
% D         = outer diameter
% xrand     = random numbers in problem space
% ntau      = total number of time-step
% ndefect   = number of defects
% param     = parameters of the problem
% nsimu     = number of simulation points
% opt       = reliability analysis tool selector
%
% OUTPUT:
% Pf            = probability of failure: Pf(1)=leak failure, Pf(2) = burst failure
% ------------------------------------------------------
global jtau ivar1 Dglob ndefect_glob param_glob

param_glob          = param;
ndefect_glob        = ndefect;
Dglob               = D;

nvar                = length(param.type);

% probdata

A                   = 'probdata.name = {';
for ivar = 1:nvar
    A               = strcat(A,'''X',num2str(ivar),'''');
    if ivar < nvar
        A           = strcat(A,',');
    else
        A           = strcat(A,'}; ');
    end
end

B                   = 'gfundata(1).expression=''limit_state(';
for ivar = 1:nvar
    B               = strcat(B,'X',num2str(ivar));
    if ivar < nvar
        B           = strcat(B,',');
    else
        B           = strcat(B,')'';');
    end
end

cd('./FORM_SORM_IS_DS')
fid = fopen('./source/inputfile_IS.m');
i=1;
tline = fgetl(fid);
C{i} = tline;
while ischar(tline)
    i = i+1;
    tline = fgetl(fid);
    C{i} = tline;
end
fclose(fid);

C{4}                = A;
C{100}              = B;

C(5:9)              = [];

delete('inputfile_ferum.m');

fid = fopen('inputfile_ferum.m', 'w');
for i = 1:numel(C)
    if C{i+1} == -1
        fprintf(fid,'%s', C{i});
        break
    else
        fprintf(fid,'%s\n', C{i});
    end
end
fclose(fid);

A = 'function g = limit_state(';
for ivar = 1:nvar
    A = strcat(A,'X',num2str(ivar));
    if ivar < nvar
        A = strcat(A,',');
    else
        A = strcat(A,')');
    end
end

B = 'zrand   = [';
for ivar = 1:nvar
    B = strcat(B,'X',num2str(ivar),'(:)');
    if ivar < nvar
        B = strcat(B,',');
    else
        B = strcat(B,'];');
    end
end

fid = fopen('./source/limit_state_sample.m');
i=1;
tline = fgetl(fid);
C{i} = tline;
while ischar(tline)
    i = i+1;
    tline = fgetl(fid);
    C{i} = tline;
end
fclose(fid);

C{1}                = A;
C{5}                = B;

delete('limit_state.m');

fid = fopen('limit_state.m', 'w');
for i = 1:numel(C)
    if C{i+1} == -1
        fprintf(fid,'%s', C{i});
        break
    else
        fprintf(fid,'%s\n', C{i});
    end
end
fclose(fid);


mu                  = zeros(nvar,1);
sd                  = ones(nvar,1);
type                = ones(nvar,1);
input_type          = zeros(nvar,1);
marg                = [type,mu,sd,mu,nan*ones(nvar,4),input_type];

corrmat             = eye(nvar);

[probdata, gfundata, analysisopt, femodel, randomfield] = inputfile_ferum(marg,corrmat,nsimu);

addpath(genpath('../../ferum'))

Pf_form = zeros(ntau,2);
Pf = Pf_form;

addpath('../FORM_SORM_IS_DS')
for itau = 1 : ntau
    jtau                    = itau;
    for jvar = 1:2
        ivar1 = jvar;
        if opt == 5
            analysisopt.analysistype    = 10;
            ferum
            Pf(itau,jvar)          = formresults.pf1;
        elseif opt == 6
            error('This is currently not working')
%             analysisopt.analysistype    = 10;
%             ferum
% %             Pf_form(itau,jvar)          = formresults.pf1;
%             analysisopt.analysistype    = 13;
%             ferum
%             Pf(itau,jvar)          = sormcfhresults.pf2_breitung;
        elseif opt == 4
            analysisopt.analysistype    = 10;
            ferum
%             Pf_form(itau,jvar)          = formresults.pf1;
            analysisopt.analysistype    = 21;
            ferum
            Pf(itau,jvar)            = simulationresults.pf;
        elseif opt == 3
            analysisopt.analysistype    = 22;
            ferum
            Pf(itau,jvar)            = dirsimulationresults.pf;
        end
    end
end
% if opt == 5
%     Pf = Pf_form;
% end
cd('../')
rmpath('./FORM_SORM_IS_DS')
rmpath(genpath('../ferum'))







